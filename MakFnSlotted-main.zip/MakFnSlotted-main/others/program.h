#pragma once
#include <Windows.h>
#include <intrin.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <sddl.h>
class main
{
public:


	static void program(std::string level, std::string expiry);
	static void CheckExpiry(std::string level, std::string expiry);

};
