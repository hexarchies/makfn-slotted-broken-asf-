#pragma once
#include <Windows.h>
bool initialize_table(DWORD ModuleBase, DWORD& Table);
bool check_text_section();